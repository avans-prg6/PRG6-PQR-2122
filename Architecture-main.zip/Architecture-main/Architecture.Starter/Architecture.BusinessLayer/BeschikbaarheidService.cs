﻿using Architecture.BusinessLayer.Interfaces;
using Architecture.Domain;
using System;
using System.Linq;

namespace Architecture.BusinessLayer
{
    public class BeschikbaarheidService : IBeschikbaarheidService
    {

        public void ZetBeschikbaarheid(DateTime start, DateTime einde, string omschrijving = null)
        {
            throw new NotImplementedException();
        }
    }
}