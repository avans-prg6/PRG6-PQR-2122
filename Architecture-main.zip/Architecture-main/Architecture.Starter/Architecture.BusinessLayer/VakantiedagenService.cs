﻿using Architecture.BusinessLayer.Interfaces;
using Architecture.Domain;
using System;
using System.Linq;

namespace Architecture.BusinessLayer
{
    public class VakantiedagenService : IVakantieService
    {
        public Vakantie PlanVakantie(DateTime start, DateTime einde, string omschrijving)
        {
            throw new NotImplementedException();
        }
    }
}
