﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Architecture.Domain
{
    public class MyDbSet : Microsoft.EntityFrameworkCore.DbSet<Beschikbaarheid>
    {
    }
}
